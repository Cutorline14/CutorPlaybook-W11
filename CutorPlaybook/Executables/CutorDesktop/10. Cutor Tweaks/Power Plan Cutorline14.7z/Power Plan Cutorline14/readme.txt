Power Plan Cutorline14

Haces esto con los dos:
powercfg -import "arrastras el archivo aquí"

Luego vas al Panel de Control y buscas bateria o power  y le das, cuando estes activa el que quieras.

Diferencias:
Despues lo activas desde el panel de control.
Eso de Idle On/Off, permite activar o desactivar el estado de reposo del CPU; basicamente Idle Off fuerza el CState 0, por lo tanto tu CPU va a estar todo el rato dando el maximo rendimiento (ocasiona un mayor VCore y por lo tanto mayores temperaturas, si quieres mas info busca Ley de Joule en google).
Si no quieres preocuparte por las temperaturas y throttling simplemente usa el Idle ON. Recomiendo usar el Idle ON, si usas el Idle Off; te advierto de que al abrir el Task Manager va a poner CPU al 100% ya que este mismo mide el tiempo de inactividad del CPU, basicamente se lo deshabilitamos asi que eso.